package com.capgemini.day4;

public class CollectionsDemo {

}
