package com.capgemini.day12;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.IntStream;

public class CountingSort1 {
	static int[] countingSort(int[] arr) {
		// Arrays.sort(arr);
		/*
		 * Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		 * IntStream.range(0, 100).forEach(i -> map.put(i, 0));
		 * System.out.println(map); for (int i = 0; i < arr.length; i++) { if
		 * (map.containsKey(arr[i])) { map.put(arr[i], map.get(arr[i]) + 1); }
		 * else { map.put(arr[i], 1); } if (i<100 && !map.containsKey(i)) {
		 * map.put(i, 0); } } System.out.println(map); return
		 * map.values().stream().mapToInt(i -> i).toArray();
		 */
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		IntStream.range(0, 100).forEach(i -> map.put(i, 0));
		for (int i = 0; i < arr.length; i++) {
			map.put(arr[i], map.get(arr[i]) + 1);
		}
		return map.values().stream().mapToInt(i -> i).toArray();
		/*
		 * System.out.println(map); return arr;
		 */
	}

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		int[] arr = new int[n];
		for (int arr_i = 0; arr_i < n; arr_i++) {
			arr[arr_i] = in.nextInt();
		}
		int[] result = countingSort(arr);
		for (int i = 0; i < result.length; i++) {
			System.out.print(result[i] + (i != result.length - 1 ? " " : ""));
		}
		System.out.println("");

		in.close();
	}
}
