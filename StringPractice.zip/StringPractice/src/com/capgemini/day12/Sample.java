package com.capgemini.day12;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.IntStream;

public class Sample {
	public static void main(String[] args) {
		System.out.println(new Integer(5).compareTo(new Integer(2)));
		String s = new String("111");
		char[] cd = s.toCharArray();
		
		System.out.println(Arrays.toString(cd));
		
		int[] arr = new int[100];
		Map<Integer, Integer> m = new HashMap<Integer, Integer>();
		Collection<Integer> c = m.values();
		int arr1[] = c.stream().mapToInt(i->i).toArray();
		int[] a = m.values().toArray();
	}
}
