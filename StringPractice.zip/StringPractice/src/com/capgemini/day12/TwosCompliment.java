package com.capgemini.day12;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class TwosCompliment {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt(), a, b, count;
		for (int f = 0; f < n; f++) {
			a = sc.nextInt();
			b = sc.nextInt();
			count = 0;
			for (int i = a; i <= b; i++) {
				StringBuilder s = new StringBuilder(Integer.toBinaryString(i));
				BigInteger big = new BigInteger(Integer.toBinaryString(-2)+ "");
				
				//big.
				s.re
				List<String> myList = new ArrayList<String>(Arrays.asList(s
						.split("")));
				count += Collections.frequency(myList, "1");
				/*
				 * for(int j=0;j<s.length();j++) { int x =
				 * Integer.parseInt(String.valueOf(s.charAt(j))); count+=x; }
				 */
			}
			System.out.println(count);
		}

	}
}
