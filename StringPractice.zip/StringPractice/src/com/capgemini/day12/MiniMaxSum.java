package com.capgemini.day12;

import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.LongStream;

public class MiniMaxSum {
	static void miniMaxSum(int[] arr) {
        /*long max = 0;
        long min = Long.MAX_VALUE;
        for(int i=0;i<arr.length;i++)
        {
            long sum = 0;
            for(int j=0;j<arr.length;j++)
            {
                if(i == j)
                {
                    continue;
                } else {
                    sum = sum + arr[j];
                }
            }
            if(max < sum)
                max = sum;
            if(min > sum)
                min = sum;
        }*/
		long[] lrr = Arrays.stream(arr).mapToLong(i -> i).toArray();
        long max = Arrays.stream(lrr).max().getAsLong();
        long min = Arrays.stream(lrr).min().getAsLong();
        long sum = Arrays.stream(lrr).sum();
        System.out.println((sum - max) + " " + (sum - min));
        //System.out.println(min + " "+ max);
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int[] arr = new int[5];
        for(int arr_i = 0; arr_i < 5; arr_i++){
            arr[arr_i] = in.nextInt();
        }
        miniMaxSum(arr);
        in.close();
    }
}
