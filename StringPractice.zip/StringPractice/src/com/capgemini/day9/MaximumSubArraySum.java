package com.capgemini.day9;

import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;
import java.util.stream.Collectors;
import java.util.stream.LongStream;
import java.util.stream.Stream;

public class MaximumSubArraySum {
	static long maximumSum(long[] a, long m) {

		Arrays.parallelPrefix(a, (x, y) -> ((x + y) % m));
		// Arrays.parallelPrefix(a, (x, y) -> (x + y));

		System.out.println(Arrays.toString(a));
		return 0;
		/*
		 * if (LongStream.of(a).anyMatch(i -> (i == (m - 1)))) { return m - 1; }
		 * else { Arrays.sort(a); long min = Long.MAX_VALUE;
		 * System.out.println(Arrays.toString(a)); for (int i = 1; i < a.length;
		 * i++) { if ((a[i] - a[i - 1]) < min && (a[i] - a[i - 1]) != 0) { min =
		 * a[i] - a[i - 1]; } System.out.println("min = "+min); } return m -
		 * min; }
		 */

		/*
		 * OptionalLong min = LongStream.range(0, a.length - 1) .map(i ->
		 * a[(int) (i + 1)] - a[(int) i]).min(); System.out.println(min);
		 */

		// System.out.println(Arrays.toString(a));

		// return max;
		// Arrays.stream(a).boxed().collect(Collectors.toList());

		/*
		 * for(int i=1;i<=a.length;i++){ for(int j=0;j<=a.length-i;j++){ temp
		 * =0L; for(int x=j;x<j+i;x++) { temp+=a[x]; } temp1 = temp%m;
		 * if(temp1>maxModuler) { maxModuler = temp1; } if(maxModuler == m-1) {
		 * return maxModuler; } } }
		 */

		/*
		 * int l = a.length; long max = 0, sum = 0, temp = 0; for (int i = 1; i
		 * <=a.length; i++) { for (int j = 0; j <= a.length-i; j++) { for (int k
		 * = j; k < i+j; k++) { sum = sum + a[k]; } //System.out.println(sum);
		 * temp = sum % m; if (temp == (m - 1)) return temp; if (max < (temp)) {
		 * max = temp; } sum = 0; } System.out.println(); } return max;
		 */

		/*
		 * sum = Arrays.stream(a).sum(); System.out.println(sum);
		 * 
		 * LongStream.
		 * 
		 * OptionalLong max = LongStream.range(0, sum + 1).parallel() .forEach(c
		 * -> (c % m));
		 * 
		 * System.out.println(max);
		 * 
		 * return Collections.max(set);
		 */
	}

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int q = in.nextInt();
		for (int a0 = 0; a0 < q; a0++) {
			int n = in.nextInt();
			long m = in.nextLong();
			long[] a = new long[n];
			for (int a_i = 0; a_i < n; a_i++) {
				a[a_i] = in.nextLong();
			}
			long result = maximumSum(a, m);
			System.out.println(result);
		}
		for (c = 0; c < length; c++) {
			for (i = 1; i <= length - c; i++) {
				sub = string.substring(c, c + i);
				System.out.println(sub);
			}
		}
		in.close();
	}
}
