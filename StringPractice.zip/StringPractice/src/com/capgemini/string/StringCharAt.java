package com.capgemini.string;

public class StringCharAt {
	public static void main(String[] args) {
		String str = "Capgemini";
		System.out.println(str.charAt(2));
		char position = str.charAt(6);
		
		System.out.println(position);
	}
}
