package com.capgemini.string;

import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class StairCase {

	public static void staircase(int n) {
		for (int i = 0; i < n; i++) {
			for (int k = 0; k < (n - (i + 1)); k++) {
				System.out.print(" ");
			}
			for (int j = 0; j <= i; j++) {
				System.out.print("#");
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		/*
		 * Scanner in = new Scanner(System.in); int n = in.nextInt();
		 * 
		 * for(int i=65;i<=90;i++) { System.out.print(i + ","); }
		 * camelcase("saveChangesInTheEditor"); // in.close();
		 */

		int[] arr = { 203, 204, 205, 206, 207, 208, 203, 204, 205, 206, 201,
				202 };
		int[] brr = { 203, 204, 204, 205, 206, 207, 205, 208, 203, 206, 205,
				206, 204, 209 };
		int str[] = missingNumbers(arr, brr);
		for (int i = 0; i < str.length; i++) {
			System.out.println(str[i]);
		}

		// unionIntersection();

		// similarString();
	}

	static void unionIntersection() {
		Set s1 = new HashSet();
		s1.add("Ian Darwin");
		s1.add("Bill Dooley");
		s1.add("Jesse James");

		Set s2 = new HashSet();
		s2.add("Ian Darwin");
		s2.add("Doolin' Dalton");

		Set union = new TreeSet(s1);
		union.addAll(s2); // now contains the union

		System.out.println("union = " + union);

		Set intersect = new TreeSet(s1);
		intersect.retainAll(s2);

		System.out.println("intersection = " + intersect);

		union.removeAll(intersect);
		System.out.println("intersection = " + union);
	}

	static int camelcase(String s) {
		int count = 0;
		if (s != null) {
			int length = s.length();
			if (length != 0) {
				count = 1;
				for (int i = 0; i < length; i++) {
					int codePoint = s.codePointAt(i);
					if (codePoint >= 65 && codePoint <= 90) {
						count++;
					}
				}
			}
		}
		return count;
	}

	static int[] missingNumbers(int[] arr, int[] brr) {

		Map<Integer, Integer> arrMap = duplicateHashmap(arr);
		Map<Integer, Integer> brrMap = duplicateHashmap(brr);

		int sizeArr = arrMap.size();
		int sizeBrr = brrMap.size();

		List<Integer> list = new ArrayList<Integer>();

		Set<Integer> set = new TreeSet<Integer>();
		Set<Integer> bSet = brrMap.keySet();
		Iterator<Integer> itr = bSet.iterator();

		while(itr.hasNext()) {
			int n = itr.next();
			if (!arrMap.containsKey(n)) {
				set.add(n);
			} else {
				if (arrMap.get(n) != brrMap.get(n)) {
					set.add(n);
				}
			}
		}

		// a

		/*
		 * Set bSet = bMap.keySet();
		 * 
		 * Set union = new TreeSet(aSet); union.addAll(bSet);
		 * 
		 * Set intersection = new TreeSet(aSet); intersection.retainAll(bSet);
		 * 
		 * union.removeAll(intersection); list.addAll(union);
		 * 
		 * // aSet.addAll(bSet);
		 * 
		 * // set.r
		 * 
		 * for (Integer keyBrr : bMap.keySet()) { for (Integer keyArr :
		 * aMap.keySet()) { if (keyBrr.intValue() == keyArr.intValue()) { if
		 * (bMap.get(keyBrr) != aMap.get(keyArr)) { list.add(keyBrr); } } } }
		 */

		return set.stream().mapToInt(i -> i).toArray();
	}

	public static Map<Integer, Integer> duplicateHashmap(int[] arr) {
		Map<Integer, Integer> arrMap = new TreeMap<Integer, Integer>();
		for (int i = 0; i < arr.length; i++) {
			if (arrMap.containsKey(arr[i])) {
				int value = arrMap.get(arr[i]);
				value++;
				arrMap.put(arr[i], value);
			} else {
				arrMap.put(arr[i], 1);
			}
		}
		return arrMap;
	}

	public static void similarString() {
		int sizeOfStr = 8;
		int noOfQueries = 4;
		String str = "#giggabaj";
		int[] queries = { 1, 1, 1, 2, 1, 3, 2, 4 };

		for (int i = 0; i < queries.length; i = i + 2) {

		}

	}

}