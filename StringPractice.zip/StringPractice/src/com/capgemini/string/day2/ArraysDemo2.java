package com.capgemini.string.day2;

public class ArraysDemo2 {
	public static void main(String[] args) {
		
		//Equals & DeepEquals
		
		
	}
}

class Person
{
	String name;
	int age;
	long phone;
	public Person(String name, int age, long phone) {
		super();
		this.name = name;
		this.age = age;
		this.phone = phone;
	}
	
}
