package com.capgemini.string.day2;

import java.math.BigInteger;

public class BinaryRepresentation {
	public static void main(String[] args) {
		int a = 4;
		System.out.println(Integer.toBinaryString(7));

		System.out.println(Integer.valueOf(Integer.toBinaryString(5), 2));
		BigInteger b = new BigInteger(Integer.valueOf(
				Integer.toBinaryString(5), 2) + "");
		b = b.negate();
		System.out.println(b);
		System.out.println(7 << 3);

		String inverted = "101";

		int i = Integer.parseInt(inverted, 16);
		i = ~i;
		inverted = Integer.toHexString(i);
		inverted = inverted.substring(2);
		System.out.println(inverted);
		
		int c = -2;
		//System.out.println(Integer.valueOf(Integer.toBinaryString(c)));
		
		String s = Integer.toBinaryString(c);
		System.out.println(s);
		
		BigInteger big = new BigInteger(Integer.toBinaryString(-2)+ "");
		System.out.println(big.bitCount());
	}
}
