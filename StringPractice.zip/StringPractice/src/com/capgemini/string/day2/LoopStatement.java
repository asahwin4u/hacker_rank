package com.capgemini.string.day2;

public class LoopStatement {
	public static void main(String[] args) {
		
		char ch = 65;
		System.out.println(ch);
		
	}
}
