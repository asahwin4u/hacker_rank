package com.capgemini.day10_11;

public class IntegerDemo {
	public static void main(String[] args) {
		int i = (int)0101F;
		System.out.println(i);
	}
}
